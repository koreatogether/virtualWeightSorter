// 메모리 분석 코드를 빌드에서 제외하는 헤더 파일
#ifndef EXCLUDE_MEMORY_ANALYSIS_H
#define EXCLUDE_MEMORY_ANALYSIS_H

// 메모리 분석 기능 비활성화
#ifndef MEMORY_ANALYSIS_ENABLED
#define MEMORY_ANALYSIS_ENABLED 0
#endif

#endif // EXCLUDE_MEMORY_ANALYSIS_H
