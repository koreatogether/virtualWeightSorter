# TamaDoggy

Tamagotchi clone game in Processing

## Information

This application consists of three .pde code snippets TamaDoggy, Animation, Doggy the two latter implement the required classes and the first .pde is the main app. It is based on code found at: https://www.andrew.cmu.edu/user/dboehle/tamagotchi/. For best UX run in Adnroid mode. 

## Licence

Copyright (c) 2012 Stavros Kalapothas (aka Stevaras) <stavros@ubinet.gr>.
It is free software, and may be redistributed under the terms of the GNU Licence.
